//
//  main.c
//  test
//
//  Created by Lukáš Hromadník on 28.10.13.
//  Copyright (c) 2013 Lukáš Hromadník. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct Item {
    int Data;
    struct Item * Prev;
    struct Item * Next;
};

int isEmpty(struct Item * head) {
    return ! head;
}

struct Item * getNewItem(int value) {
    struct Item * newItem = (struct Item *) malloc(sizeof(struct Item));
    
    newItem->Data = value;
    newItem->Prev = NULL;
    newItem->Next = NULL;
    
    return newItem;
}

struct Item * insertHead(struct Item * head, int value) {
    struct Item * newItem = getNewItem(value);
    
    newItem->Next = head;
    
    if ( ! isEmpty(head))
        head->Prev = newItem;
    
    return newItem;
}

struct Item * insertTail(struct Item * head, int value) {
    struct Item * newItem = getNewItem(value);
    struct Item * tmp = head;
    
    if (isEmpty(head))
        return insertHead(head, value);
    
    while (tmp->Next)
        tmp = tmp->Next;
    
    tmp->Next = newItem;
    newItem->Prev = tmp;
    
    return head;
}

struct Item * removeHead(struct Item * head) {
    if (isEmpty(head))
        return head;
    
    head = head->Next;
    
    if (head != NULL) {
        free(head->Prev);
        head->Prev = NULL;
    }
    
    return head;
}

struct Item * removeTail(struct Item * head) {
    struct Item * tmp = head;
    
    if (isEmpty(head))
        return head;
    
    while (tmp->Next)
        tmp = tmp->Next;
    
    tmp = tmp->Prev;
    
    free(tmp->Next);
    tmp->Next = NULL;
    
    return head;
}

struct Item * removeItem(struct Item * head, int value) {
    struct Item * tmp = head;
    
    if (tmp->Data == value)
        return removeHead(head);

    while (tmp->Data != value)
        if (tmp->Next)
            tmp = tmp->Next;
        else
            return head;
    
    if ( ! tmp->Next)
        return removeTail(head);
    
    tmp->Prev->Next = tmp->Next;
    tmp->Next->Prev = tmp->Prev;
    
    free(tmp);
    
    return head;
}

void printAll(struct Item * head) {
    while (head != NULL) {
        printf("%d\n", head->Data);
        head = head->Next;
    }
}

int main(int argc, const char * argv[])
{
    struct Item * head = NULL;
//    head = getNewItem(10);
    head = insertTail(head, 4);
    head = insertHead(head, 14);
    head = insertHead(head, 41);
    head = insertTail(head, 42);
//    head = removeHead(head);
    head = removeItem(head, 4);
    printAll(head);

}

