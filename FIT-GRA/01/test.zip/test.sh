#!/bin/bash

rm -f *_my.txt

testdiff() {
	./a.out "$1_in.txt" "$1_my.txt"
	echo -n "Test $1.txt ... "
	if [ -n "$2" ]; then
		diff "$1"_out.txt "$1"_my.txt >/dev/null 2>&1 && echo -e "OK" || echo -e "FAIL"
	else
		diff "$1"_out.txt "$1"_my.txt && echo -e "OK" || echo -e "FAIL"
	fi
}

for i in {1..14}; do
	testdiff $i
done
